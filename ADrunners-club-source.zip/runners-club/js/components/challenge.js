/* Challenge status logic and challenge cards. */
(function () {
  const h = RC.h, ui = RC.ui, D = RC.dates;

  function status(ch) {
    const now = new Date(), s = D.start(ch.start), e = D.end(ch.end);
    if (now < s) {
      const d = Math.ceil((s - now) / 864e5);
      return { key: 'upcoming', tone: 'amber', label: d <= 1 ? 'Opens tomorrow' : 'Opens in ' + d + ' days', days: d };
    }
    if (now <= e) {
      const d = Math.ceil((e - now) / 864e5);
      return { key: 'live', tone: 'lime', label: d <= 1 ? 'Live · last day' : 'Live · ' + d + ' days left', days: d };
    }
    return { key: 'ended', tone: 'neutral', label: 'Closed', days: 0 };
  }

  const kindLabel = (ch) => (ch.kind === 'weekly' ? 'WEEKLY' : 'MONTHLY');

  function meta(ch) {
    const row = (k, v) => h('div', null, h('dt', null, k), h('dd', null, v));
    return h('dl', { class: 'ch-meta' },
      row('Window', D.range(ch.start, ch.end)),
      row('Level', ch.level),
      row('Counts', ch.counts));
  }

  function rules(ch) {
    return h('details', { class: 'rules' },
      h('summary', null, 'Draft rules'),
      h('ul', null, ch.rules.map((r) => h('li', null, r))));
  }

  function card(ch) {
    const st = status(ch);
    return h('article', { class: 'ch-card' },
      h('div', { class: 'ch-top' },
        h('span', { class: 'kind kind-' + ch.kind }, kindLabel(ch)),
        h('span', { class: 'chip chip-' + st.tone }, st.label)),
      h('h3', { class: 'ch-title' }, ch.title),
      h('p', { class: 'ch-goal' }, h('span', { class: 'ch-num' }, ch.goal.value), h('span', { class: 'ch-unit' }, ch.goal.unit)),
      h('p', { class: 'ch-blurb' }, ch.blurb),
      meta(ch),
      rules(ch),
      h('div', { class: 'ch-foot' },
        ui.demoTag('DEMO CHALLENGE'),
        ui.btn({ label: 'Join challenge', href: '#register', variant: 'ghost', small: true })));
  }

  function featured(ch) {
    const st = status(ch);
    return h('article', { class: 'feature' },
      h('div', { class: 'feature-main' },
        h('div', { class: 'ch-top' },
          h('span', { class: 'kind kind-weekly' }, 'FEATURED · WEEKLY'),
          h('span', { class: 'chip chip-' + st.tone }, st.label)),
        h('h3', { class: 'feature-title' }, ch.title),
        h('p', { class: 'ch-blurb' }, ch.blurb),
        meta(ch),
        h('div', { class: 'cta-row' },
          ui.btn({ label: 'Join Your First Challenge', href: '#register' }),
          ui.btn({ label: 'All challenges', href: '#challenges', variant: 'ghost' })),
        h('p', null, ui.demoTag('DEMO CHALLENGE'))),
      h('div', { class: 'feature-num', 'aria-hidden': 'true' },
        h('span', { class: 'big' }, ch.goal.value),
        h('span', { class: 'unit' }, ch.goal.unit)),
      h('div', { class: 'feature-rules' }, rules(ch)));
  }

  RC.challenge = { status, card, featured };
})();
