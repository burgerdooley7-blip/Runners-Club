/* Service layer — the ONLY place pages get data from.
   Pages never import js/data/demo.js directly. That keeps the swap to Supabase
   to this one file: replace each function body, keep the signatures.

   Planned Supabase mapping
   ─────────────────────────
   auth         supabase.auth.signUp / signInWithPassword / signOut / getSession
   profiles     table `profiles` (id = auth.uid(), display_name, city, level, role)
   challenges   table `challenges` (kind, title, goal_value, goal_unit, starts_on,
                ends_on, level, rules jsonb). Public read, admin write.
   activities   table `activities` (user_id, challenge_id, ran_on, distance_km,
                duration_s, source, proof_path, status). RLS: a user reads and
                inserts only their own rows. status enum:
                pending | needs_info | accepted | not_accepted.
   leaderboard  SQL views over `activities` WHERE status = 'accepted' only,
                grouped by week / month. Pending runs never appear.
   storage      private bucket `run-proofs`, path {user_id}/{activity_id}/{file}.
                No public URLs. Reviewers read through short-lived signed URLs.
   admin        `profiles.role = 'admin'` enforced by RLS and server-side checks.
                The browser never decides who is an admin.
   contact      table `contact_messages` (insert-only for anon, read for admin). */
(function () {
  const notConnected = (what) => ({
    ok: false,
    code: 'NOT_CONNECTED',
    message: what + ' is not connected yet. This is a design preview, so nothing was saved or sent.'
  });

  RC.services = {
    auth: {
      async getSession() { return null; }, // no real session exists in the preview
      async signIn() { return notConnected('Sign-in'); },
      async signUp() { return notConnected('Registration'); },
      async signOut() { return notConnected('Sign-out'); }
    },

    profiles: {
      async getMine() { return RC.demo.me; } // DEMO profile
    },

    challenges: {
      async list() { return RC.demo.challenges.slice(); },
      async getFeaturedWeekly() {
        const weekly = RC.demo.challenges.filter((c) => c.kind === 'weekly');
        const open = weekly.filter((c) => RC.challenge.status(c).key !== 'ended');
        return open.find((c) => c.featured) || open[0] || weekly[0];
      }
    },

    leaderboard: {
      // period: 'weekly' | 'monthly'; city: 'all' or a city name
      async get(opts) {
        const o = opts || {};
        const monthly = o.period === 'monthly';
        const city = o.city || 'all';
        const rows = RC.demo.runners
          .filter((r) => city === 'all' || r.city === city)
          .map((r) => Object.assign({}, r, {
            km: monthly ? r.monthKm : r.weeklyKm,
            runs: monthly ? r.monthRuns : r.weeklyRuns
          }))
          .sort((a, b) => b.km - a.km);
        return rows.map((r, i) => Object.assign({ rank: i + 1 }, r));
      }
    },

    activities: {
      async listMine() { return RC.demo.myActivities.slice(); },
      async progressMine() { return RC.demo.myProgress.slice(); },
      async weekMine() { return RC.demo.myWeek.slice(); },
      async submit(/* payload */) { return notConnected('Run submission'); }
    },

    storage: {
      async uploadProof(/* file */) { return notConnected('Proof upload'); }
    },

    contact: {
      async send(/* payload */) { return notConnected('The contact form'); }
    }
  };
})();
